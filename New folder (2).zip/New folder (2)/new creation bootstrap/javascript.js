
//On load function is calling
//window.onload = function () {
//    window.scrollTo(0, 0);
//};

//this function is for number counting which is of Number Count Section
document.addEventListener('DOMContentLoaded', function () {
    var counters = document.querySelectorAll('.counter-numbers');
    var speed = 200;

    function startCounting() {
        counters.forEach(counter => {
            var target = +counter.getAttribute('data-number');
            var count = +counter.innerText;
            var inc = target / speed;
            var observer = new IntersectionObserver(entries => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        var updateCount = () => {
                            if (count < target) {
                                counter.innerText = Math.ceil(count + inc);
                                setTimeout(updateCount, 1);
                                count += inc;
                            } else {
                                counter.innerText = target;
                                observer.unobserve(counter.parentElement);
                            }
                        };
                        updateCount();
                    }
                });
            });
            observer.observe(counter.parentElement);
        });
    }

    startCounting();
});
//this function is Slider
var swiper = new Swiper('.slides-3', {
    slidesPerView: 3,
    spaceBetween: 10,
    loop: true,
    autoplay: {
        delay: 2000,
        disableOnInteraction: false,
    },
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

});

//This function is for Sent Message 
document.getElementById('submit-btn').addEventListener('click', function () {
    var loadingIndicator = document.getElementById('loading');
    var sentMessage = document.getElementById('sent-message');

    loadingIndicator.style.display = 'block';

    setTimeout(function () {
        loadingIndicator.style.display = 'none';
        sentMessage.style.display = 'block';
    }, 2000);
});

//RegistrationForm
         function redirectToRegistration() {
        window.location.href = 'RegistrationForm.html';
}


