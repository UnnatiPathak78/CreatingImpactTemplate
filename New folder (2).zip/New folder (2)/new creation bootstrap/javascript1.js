document.getElementById('modalAgreeCheckbox').addEventListener('change', function () {
    document.getElementById('okButton').disabled = !this.checked;
});


document.getElementById('okButton').addEventListener('click', function () {
    document.getElementById('submitButton').disabled = false;
    document.getElementById('termsModal').classList.remove('show');
    document.getElementById('termsModal').style.display = 'none';
    document.getElementsByClassName('modal-backdrop')[0].remove();
    document.body.style.overflowY = 'auto';
});

document.querySelectorAll('input[name="nationality"]').forEach(function (radio) {
    radio.addEventListener('change', function () {
        if (this.value === 'Indian') {
            document.getElementById('aadharUploadSection').style.display = 'block';
            document.getElementById('AadharCard').required = true;
        } else {
            document.getElementById('aadharUploadSection').style.display = 'none';
            document.getElementById('AadharCard').required = false;
        }
    });
});